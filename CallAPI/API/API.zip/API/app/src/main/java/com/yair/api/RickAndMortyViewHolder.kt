package com.yair.api

import android.support.v7.widget.RecyclerView
import android.view.View

class RickAndMortyViewHolder(view: View):RecyclerView.ViewHolder(view) {
    fun bind (image:String){

    }
}