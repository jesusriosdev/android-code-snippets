package com.yair.api

import android.support.v7.widget.RecyclerView

class RickAndMortyAdapter(val images:List<String>):RecyclerView.Adapter<RickAndMortyViewHolder> {



}